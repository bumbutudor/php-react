-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 21, 2021 at 02:44 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dictionar`
--

-- --------------------------------------------------------

--
-- Table structure for table `cuvinte`
--

CREATE TABLE `cuvinte` (
  `id` int(11) UNSIGNED NOT NULL,
  `cuvant` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `predefinitie` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `definitie` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `dictionar_id` int(11) NOT NULL,
  `lexicograf_id` int(11) NOT NULL,
  `activ` tinyint(1) NOT NULL DEFAULT 1,
  `adaugat` timestamp NOT NULL DEFAULT current_timestamp(),
  `modificat` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cuvinte`
--

INSERT INTO `cuvinte` (`id`, `cuvant`, `predefinitie`, `definitie`, `dictionar_id`, `lexicograf_id`, `activ`, `adaugat`, `modificat`) VALUES
(1, 'Test', 'Test predefinitie', 'Test definitie', 1, 1, 1, '2021-01-19 20:29:51', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `dictionare`
--

CREATE TABLE `dictionare` (
  `id` int(11) UNSIGNED NOT NULL,
  `denumire` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descriere` tinytext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `dictionare`
--

INSERT INTO `dictionare` (`id`, `denumire`, `descriere`) VALUES
(1, 'Dictionar 1', 'Cuvinte din dictionarul 1.'),
(2, 'Dictionar 2', 'Cuvinte din dictionarul 2.'),
(3, 'Dictionar 3', 'Cuvinte din dictionarul 3.');

-- --------------------------------------------------------

--
-- Table structure for table `lexicograf`
--

CREATE TABLE `lexicograf` (
  `id` int(11) UNSIGNED NOT NULL,
  `nume` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `prenume` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `parola` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `confirmat` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `lexicograf`
--

INSERT INTO `lexicograf` (`id`, `nume`, `prenume`, `parola`, `email`, `confirmat`) VALUES
(1, 'Bumbu', 'Test', 'test123', 'tudor.bumbu@math.md', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cuvinte`
--
ALTER TABLE `cuvinte`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dictionare`
--
ALTER TABLE `dictionare`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lexicograf`
--
ALTER TABLE `lexicograf`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cuvinte`
--
ALTER TABLE `cuvinte`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `dictionare`
--
ALTER TABLE `dictionare`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `lexicograf`
--
ALTER TABLE `lexicograf`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
